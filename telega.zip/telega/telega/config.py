import os

# Токен бота - замените на свой
BOT_TOKEN = "8543235647:AAHFWyOCfmBAyriJ14mODFpxTJRtQb8CNhA"

# Настройки базы данных
DATABASE_PATH = "user_data.db"

# Настройки напоминаний
REMINDER_HOUR = 21  # 9 PM
REMINDER_MINUTE = 0