import sqlite3
import json
from datetime import datetime, date
from typing import List, Dict, Optional, Tuple
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseHandler:
    def __init__(self, db_path: str = "user_data.db"):
        self.db_path = db_path
        self.init_database()
    
    def get_connection(self):
        return sqlite3.connect(self.db_path)
    
    def init_database(self):
        """Инициализация базы данных"""
        with self.get_connection() as conn:
            # Таблица пользователей
            conn.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    first_name TEXT,
                    last_name TEXT,
                    reminder_hour INTEGER DEFAULT 21,
                    reminder_minute INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Таблица ежедневных записей
            conn.execute('''
                CREATE TABLE IF NOT EXISTS daily_entries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    entry_date DATE NOT NULL,
                    mood INTEGER NOT NULL CHECK (mood >= 1 AND mood <= 5),
                    work_hours REAL NOT NULL CHECK (work_hours >= 0),
                    sleep_hours REAL NOT NULL CHECK (sleep_hours >= 0),
                    comment TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(user_id, entry_date),
                    FOREIGN KEY (user_id) REFERENCES users(user_id)
                )
            ''')
            
            # Индексы для производительности
            conn.execute('CREATE INDEX IF NOT EXISTS idx_user_date ON daily_entries(user_id, entry_date)')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_mood ON daily_entries(mood)')
            
            logger.info("Database initialized successfully")
    
    def register_user(self, user_id: int, username: str = None, 
                     first_name: str = None, last_name: str = None) -> bool:
        """Регистрация нового пользователя"""
        try:
            with self.get_connection() as conn:
                conn.execute('''
                    INSERT OR IGNORE INTO users (user_id, username, first_name, last_name)
                    VALUES (?, ?, ?, ?)
                ''', (user_id, username, first_name, last_name))
            logger.info(f"User {user_id} registered")
            return True
        except Exception as e:
            logger.error(f"Error registering user: {e}")
            return False
    
    def add_entry(self, user_id: int, entry_date: date, mood: int, 
                  work_hours: float, sleep_hours: float, comment: str = None) -> bool:
        """Добавление записи за день"""
        try:
            with self.get_connection() as conn:
                conn.execute('''
                    INSERT OR REPLACE INTO daily_entries 
                    (user_id, entry_date, mood, work_hours, sleep_hours, comment)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (user_id, entry_date, mood, work_hours, sleep_hours, comment))
            logger.info(f"Entry added for user {user_id} on {entry_date}")
            return True
        except Exception as e:
            logger.error(f"Error adding entry: {e}")
            return False
    
    def get_entries(self, user_id: int, start_date: date, end_date: date) -> List[Dict]:
        """Получение записей за период"""
        try:
            with self.get_connection() as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.execute('''
                    SELECT entry_date, mood, work_hours, sleep_hours, comment
                    FROM daily_entries
                    WHERE user_id = ? AND entry_date BETWEEN ? AND ?
                    ORDER BY entry_date DESC
                ''', (user_id, start_date, end_date))
                
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Error getting entries: {e}")
            return []
    
    def get_last_entry_date(self, user_id: int) -> Optional[date]:
        """Получение даты последней записи"""
        try:
            with self.get_connection() as conn:
                cursor = conn.execute('''
                    SELECT MAX(entry_date) as last_date
                    FROM daily_entries
                    WHERE user_id = ?
                ''', (user_id,))
                row = cursor.fetchone()
                if row and row[0]:
                    return datetime.strptime(row[0], '%Y-%m-%d').date()
                return None
        except Exception as e:
            logger.error(f"Error getting last entry: {e}")
            return None
    
    def get_statistics(self, user_id: int, period: str = 'week') -> Dict:
        """Получение статистики за период"""
        end_date = date.today()
        
        if period == 'week':
            from datetime import timedelta
            start_date = end_date - timedelta(days=7)
        elif period == 'month':
            from datetime import timedelta
            start_date = end_date - timedelta(days=30)
        else:
            return {}
        
        entries = self.get_entries(user_id, start_date, end_date)
        
        if not entries:
            return {}
        
        moods = [e['mood'] for e in entries]
        work_hours = [e['work_hours'] for e in entries]
        sleep_hours = [e['sleep_hours'] for e in entries]
        
        return {
            'period': period,
            'days_count': len(entries),
            'avg_mood': sum(moods) / len(moods),
            'avg_work': sum(work_hours) / len(work_hours),
            'avg_sleep': sum(sleep_hours) / len(sleep_hours),
            'max_mood': max(moods),
            'min_mood': min(moods),
            'total_work': sum(work_hours),
            'entries': entries
        }
    
    def get_reminder_time(self, user_id: int) -> Tuple[int, int]:
        """Получение времени напоминания для пользователя"""
        try:
            with self.get_connection() as conn:
                cursor = conn.execute('''
                    SELECT reminder_hour, reminder_minute
                    FROM users
                    WHERE user_id = ?
                ''', (user_id,))
                row = cursor.fetchone()
                if row:
                    return row[0], row[1]
                return 21, 0
        except Exception as e:
            logger.error(f"Error getting reminder time: {e}")
            return 21, 0
    
    def update_reminder_time(self, user_id: int, hour: int, minute: int) -> bool:
        """Обновление времени напоминания"""
        try:
            with self.get_connection() as conn:
                conn.execute('''
                    UPDATE users
                    SET reminder_hour = ?, reminder_minute = ?
                    WHERE user_id = ?
                ''', (hour, minute, user_id))
            return True
        except Exception as e:
            logger.error(f"Error updating reminder time: {e}")
            return False
    
    def clear_user_data(self, user_id: int) -> bool:
        """Очистка всех данных пользователя"""
        try:
            with self.get_connection() as conn:
                conn.execute('DELETE FROM daily_entries WHERE user_id = ?', (user_id,))
            logger.info(f"All data cleared for user {user_id}")
            return True
        except Exception as e:
            logger.error(f"Error clearing data: {e}")
            return False