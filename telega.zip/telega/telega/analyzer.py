import pandas as pd
from datetime import datetime, timedelta, date
from typing import List, Dict, Tuple
import numpy as np

class DataAnalyzer:
    @staticmethod
    def get_insights(entries: List[Dict]) -> List[str]:
        """Генерация инсайтов на основе данных"""
        if len(entries) < 3:
            return ["Недостаточно данных для анализа. Добавьте больше записей!"]
        
        insights = []
        df = pd.DataFrame(entries)
        df['entry_date'] = pd.to_datetime(df['entry_date'])
        
        # Анализ сна и настроения
        sleep_by_mood = df.groupby(df['sleep_hours'].round(1))['mood'].mean()
        if not sleep_by_mood.empty:
            best_sleep = sleep_by_mood.idxmax()
            insights.append(f"💤 Оптимальная продолжительность сна: {best_sleep} часов (настроение выше на {sleep_by_mood.max():.1f}/5)")
        
        # Анализ продуктивности и настроения
        work_by_mood = df.groupby(df['work_hours'].round(1))['mood'].mean()
        if not work_by_mood.empty:
            best_work = work_by_mood.idxmax()
            insights.append(f"📚 Наиболее продуктивное время работы: {best_work} часов (настроение {work_by_mood.max():.1f}/5)")
        
        # Корреляция между сном и продуктивностью
        correlation = df['sleep_hours'].corr(df['work_hours'])
        if not np.isnan(correlation):
            if correlation > 0.3:
                insights.append(f"📈 Положительная связь между сном и продуктивностью (корреляция: {correlation:.2f})")
            elif correlation < -0.3:
                insights.append(f"📉 Отрицательная связь между сном и продуктивностью (корреляция: {correlation:.2f})")
        
        # Лучший день недели
        df['weekday'] = df['entry_date'].dt.day_name()
        best_day = df.groupby('weekday')['mood'].mean().idxmax()
        insights.append(f"📅 Лучший день недели: {best_day}")
        
        # Тенденция настроения
        if len(df) >= 5:
            recent_avg = df.head(3)['mood'].mean()
            older_avg = df.tail(3)['mood'].mean()
            if recent_avg > older_avg + 0.5:
                insights.append("📈 Твое настроение улучшается! Так держать!")
            elif recent_avg < older_avg - 0.5:
                insights.append("📉 Заметно снижение настроения. Возможно, стоит отдохнуть и выспаться.")
        
        return insights
    
    @staticmethod
    def get_weekday_pattern(entries: List[Dict]) -> Dict:
        """Анализ паттернов по дням недели"""
        df = pd.DataFrame(entries)
        df['entry_date'] = pd.to_datetime(df['entry_date'])
        df['weekday'] = df['entry_date'].dt.day_name()
        
        pattern = {}
        weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        russian_days = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС']
        
        for eng_day, rus_day in zip(weekdays, russian_days):
            day_data = df[df['weekday'] == eng_day]
            if not day_data.empty:
                pattern[rus_day] = {
                    'avg_mood': day_data['mood'].mean(),
                    'avg_work': day_data['work_hours'].mean(),
                    'avg_sleep': day_data['sleep_hours'].mean(),
                    'count': len(day_data)
                }
        
        return pattern
    
    @staticmethod
    def get_correlation_analysis(entries: List[Dict]) -> str:
        """Анализ корреляций между показателями"""
        if len(entries) < 5:
            return "Недостаточно данных для корреляционного анализа"
        
        df = pd.DataFrame(entries)
        
        # Корреляция работа-настроение
        work_mood_corr = df['work_hours'].corr(df['mood'])
        
        # Корреляция сон-настроение
        sleep_mood_corr = df['sleep_hours'].corr(df['mood'])
        
        result = "📊 Корреляционный анализ:\n\n"
        result += f"Работа ↔ Настроение: {work_mood_corr:.2f}\n"
        if work_mood_corr > 0.3:
            result += "✓ Умеренная положительная связь\n"
        elif work_mood_corr < -0.3:
            result += "✓ Умеренная отрицательная связь\n"
        else:
            result += "✓ Слабая связь\n"
        
        result += f"\nСон ↔ Настроение: {sleep_mood_corr:.2f}\n"
        if sleep_mood_corr > 0.3:
            result += "✓ Сон положительно влияет на настроение\n"
        elif sleep_mood_corr < -0.3:
            result += "✓ Обратная зависимость (редкий случай)\n"
        else:
            result += "✓ Прямой зависимости не обнаружено\n"
        
        return result