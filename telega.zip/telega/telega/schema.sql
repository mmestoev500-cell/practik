-- Схема базы данных для бота отслеживания продуктивности

-- Таблица пользователей
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    last_name TEXT,
    reminder_hour INTEGER DEFAULT 21,
    reminder_minute INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица ежедневных записей
CREATE TABLE IF NOT EXISTS daily_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    entry_date DATE NOT NULL,
    mood INTEGER NOT NULL CHECK (mood >= 1 AND mood <= 5),
    work_hours REAL NOT NULL CHECK (work_hours >= 0),
    sleep_hours REAL NOT NULL CHECK (sleep_hours >= 0),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, entry_date),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Индексы для оптимизации запросов
CREATE INDEX idx_user_date ON daily_entries(user_id, entry_date);
CREATE INDEX idx_mood ON daily_entries(mood);
CREATE INDEX idx_work_hours ON daily_entries(work_hours);
CREATE INDEX idx_sleep_hours ON daily_entries(sleep_hours);