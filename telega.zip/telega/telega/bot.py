import telebot
from telebot.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from datetime import datetime, date, timedelta
import logging
import threading
import time
from config import BOT_TOKEN, DATABASE_PATH, REMINDER_HOUR, REMINDER_MINUTE
from db_handler import DatabaseHandler
from analyzer import DataAnalyzer
import re

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

bot = telebot.TeleBot(BOT_TOKEN)
db = DatabaseHandler(DATABASE_PATH)
analyzer = DataAnalyzer()

# Хранилище временных данных пользователей
user_sessions = {}

class UserSession:
    def __init__(self, user_id):
        self.user_id = user_id
        self.mood = None
        self.work_hours = None
        self.sleep_hours = None
        self.comment = None
        self.step = 0  # 0: mood, 1: work, 2: sleep, 3: comment
        self.entry_date = date.today()

def create_main_keyboard():
    """Создание главной клавиатуры"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    keyboard.add(
        KeyboardButton("➕ Записать день"),
        KeyboardButton("📊 Статистика"),
        KeyboardButton("📈 Мои инсайты"),
        KeyboardButton("📜 История"),
        KeyboardButton("⚙️ Настройки"),
        KeyboardButton("❌ Очистить данные"),
        KeyboardButton("🆘 Помощь")
    )
    return keyboard

def create_mood_keyboard():
    """Создание клавиатуры для оценки настроения"""
    keyboard = InlineKeyboardMarkup(row_width=5)
    buttons = [
        InlineKeyboardButton("1 😞", callback_data="mood_1"),
        InlineKeyboardButton("2 😐", callback_data="mood_2"),
        InlineKeyboardButton("3 🙂", callback_data="mood_3"),
        InlineKeyboardButton("4 😊", callback_data="mood_4"),
        InlineKeyboardButton("5 🤩", callback_data="mood_5")
    ]
    keyboard.add(*buttons)
    return keyboard

def create_hours_keyboard(hours_list, prefix):
    """Создание клавиатуры для выбора часов"""
    keyboard = InlineKeyboardMarkup(row_width=4)
    buttons = []
    for h in hours_list:
        buttons.append(InlineKeyboardButton(f"{h} ч", callback_data=f"{prefix}_{h}"))
    buttons.append(InlineKeyboardButton("✏️ Своё значение", callback_data=f"{prefix}_custom"))
    keyboard.add(*buttons)
    return keyboard

@bot.message_handler(commands=['start'])
def send_welcome(message):
    user = message.from_user
    db.register_user(user.id, user.username, user.first_name, user.last_name)
    
    welcome_text = f"""
🌟 Привет, {user.first_name}! Я помогу тебе отслеживать самочувствие и продуктивность.

📝 Что я умею:
• Ежедневно записывать твоё настроение, часы работы и сна
• Анализировать данные и давать персонализированные инсайты
• Показывать статистику за неделю и месяц
• Находить скрытые закономерности в твоих привычках

🎯 Как использовать:
1. Нажми "➕ Записать день" или отправь /add
2. Оцени настроение по шкале 1-5
3. Укажи часы продуктивной работы/учебы
4. Укажи продолжительность сна
5. Добавь комментарий (опционально)

📊 Команды:
/add - записать день
/stats - статистика
/history - история записей
/settings - настройки
/clear - очистить данные
/help - помощь

Начни сегодня! Нажми "➕ Записать день" ⬇️
"""
    bot.send_message(message.chat.id, welcome_text, reply_markup=create_main_keyboard())

@bot.message_handler(commands=['help'])
def send_help(message):
    help_text = """
🆘 Справка по использованию:

📝 Запись дня:
• Выбери "➕ Записать день" в меню
• Оцени настроение от 1 (ужасно) до 5 (отлично)
• Укажи часы работы/учебы (можно дробные, например 2.5)
• Укажи часы сна (можно дробные)
• По желанию добавь комментарий

📊 Статистика:
• За неделю - средние показатели за 7 дней
• За месяц - средние показатели за 30 дней
• Инсайты - персональные выводы на основе данных
• Графики - визуализация твоих показателей (в разработке)

⚙️ Настройки:
• Установка времени ежедневного напоминания

💡 Советы:
• Заполняй данные ежедневно для точной аналитики
• Чем больше данных, тем точнее инсайты
• Используй комментарии для заметок

По всем вопросам: @support_bot
"""
    bot.send_message(message.chat.id, help_text, reply_markup=create_main_keyboard())

@bot.message_handler(commands=['add'])
def start_entry(message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    
    # Проверка, не заполнил ли пользователь уже сегодня
    today = date.today()
    entries = db.get_entries(user_id, today, today)
    
    if entries:
        keyboard = InlineKeyboardMarkup()
        keyboard.add(
            InlineKeyboardButton("✅ Да, перезаписать", callback_data="override_yes"),
            InlineKeyboardButton("❌ Нет, отмена", callback_data="override_no")
        )
        bot.send_message(chat_id, "⚠️ За сегодня уже есть запись. Хочешь перезаписать её?", reply_markup=keyboard)
        return
    
    # Создаем новую сессию
    user_sessions[user_id] = UserSession(user_id)
    
    # Шаг 1: Оценка настроения
    bot.send_message(chat_id, "🌟 Оцени своё настроение сегодня:", reply_markup=create_mood_keyboard())

@bot.message_handler(commands=['stats'])
def show_stats_menu(message):
    chat_id = message.chat.id
    
    keyboard = InlineKeyboardMarkup(row_width=2)
    keyboard.add(
        InlineKeyboardButton("📅 За неделю", callback_data="stats_week"),
        InlineKeyboardButton("🗓 За месяц", callback_data="stats_month"),
        InlineKeyboardButton("🔍 Мои инсайты", callback_data="insights"),
        InlineKeyboardButton("📈 Корреляция", callback_data="correlation")
    )
    
    bot.send_message(chat_id, "📊 Что хочешь узнать?", reply_markup=keyboard)

@bot.message_handler(commands=['history'])
def show_history(message):
    user_id = message.from_user.id
    entries = db.get_entries(user_id, date.today() - timedelta(days=30), date.today())
    
    if not entries:
        bot.send_message(message.chat.id, "📭 История пуста. Добавь несколько записей!")
        return
    
    history_text = "📜 Последние 10 записей:\n\n"
    for i, entry in enumerate(entries[:10], 1):
        entry_date = entry['entry_date']
        mood_emoji = ["😞", "😐", "🙂", "😊", "🤩"][entry['mood'] - 1]
        history_text += f"{i}. {entry_date}: {mood_emoji} {entry['mood']}/5 | Работа: {entry['work_hours']}ч | Сон: {entry['sleep_hours']}ч\n"
        if entry.get('comment'):
            history_text += f"   💬 {entry['comment']}\n"
    
    bot.send_message(message.chat.id, history_text, reply_markup=create_main_keyboard())

@bot.message_handler(commands=['settings'])
def settings_menu(message):
    user_id = message.from_user.id
    current_hour, current_minute = db.get_reminder_time(user_id)
    
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("⏰ Изменить время напоминания", callback_data="set_reminder"))
    keyboard.add(InlineKeyboardButton(f"📌 Текущее время: {current_hour:02d}:{current_minute:02d}", callback_data="show_reminder"))
    
    bot.send_message(message.chat.id, "⚙️ Настройки бота:", reply_markup=keyboard)

@bot.message_handler(commands=['clear'])
def clear_data_confirm(message):
    keyboard = InlineKeyboardMarkup()
    keyboard.add(
        InlineKeyboardButton("⚠️ ДА, УДАЛИТЬ ВСЁ", callback_data="clear_confirm"),
        InlineKeyboardButton("❌ ОТМЕНА", callback_data="clear_cancel")
    )
    
    bot.send_message(message.chat.id, 
                    "❌ ВНИМАНИЕ! Это действие безвозвратно удалит ВСЕ твои данные.\n\n"
                    "Ты уверен?", 
                    reply_markup=keyboard)

@bot.message_handler(func=lambda message: True)
def handle_text(message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    text = message.text
    
    # Обработка текстовых команд из меню
    if text == "➕ Записать день":
        start_entry(message)
    elif text == "📊 Статистика":
        show_stats_menu(message)
    elif text == "📈 Мои инсайты":
        show_insights(message)
    elif text == "📜 История":
        show_history(message)
    elif text == "⚙️ Настройки":
        settings_menu(message)
    elif text == "❌ Очистить данные":
        clear_data_confirm(message)
    elif text == "🆘 Помощь":
        send_help(message)
    elif user_id in user_sessions:
        session = user_sessions[user_id]
        
        # Обработка комментария
        if session.step == 3:
            if text.lower() != "пропустить":
                session.comment = text
            session.step = 4
            
            # Сохраняем запись
            if db.add_entry(user_id, session.entry_date, session.mood, 
                           session.work_hours, session.sleep_hours, session.comment):
                # Формируем сообщение о сохранении
                mood_emoji = ["😞", "😐", "🙂", "😊", "🤩"][session.mood - 1]
                summary = f"✅ Запись сохранена!\n\n"
                summary += f"📅 Дата: {session.entry_date}\n"
                summary += f"🎭 Настроение: {mood_emoji} {session.mood}/5\n"
                summary += f"💼 Работа/учеба: {session.work_hours} ч\n"
                summary += f"😴 Сон: {session.sleep_hours} ч\n"
                if session.comment:
                    summary += f"💬 Комментарий: {session.comment}\n"
                
                bot.send_message(chat_id, summary, reply_markup=create_main_keyboard())
            else:
                bot.send_message(chat_id, "❌ Ошибка при сохранении. Попробуй позже.", reply_markup=create_main_keyboard())
            
            del user_sessions[user_id]
        else:
            # Обработка пользовательского ввода часов
            try:
                hours = float(text.replace(',', '.'))
                if hours < 0 or hours > 24:
                    bot.send_message(chat_id, "❌ Пожалуйста, введи число от 0 до 24")
                    return
                
                if session.step == 1:
                    session.work_hours = hours
                    session.step = 2
                    bot.send_message(chat_id, "😴 Сколько часов ты спал?", 
                                   reply_markup=create_hours_keyboard([6, 7, 8, 9], "sleep"))
                elif session.step == 2:
                    session.sleep_hours = hours
                    session.step = 3
                    
                    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
                    keyboard.add(KeyboardButton("Пропустить"))
                    
                    bot.send_message(chat_id, "💭 Хочешь добавить комментарий? (Напиши текст или нажми 'Пропустить')", 
                                   reply_markup=keyboard)
            except ValueError:
                bot.send_message(chat_id, "❌ Пожалуйста, введи число (например: 7.5, 8, 2)")

def show_insights(message):
    user_id = message.from_user.id
    entries = db.get_entries(user_id, date.today() - timedelta(days=30), date.today())
    
    if len(entries) < 3:
        bot.send_message(message.chat.id, 
                        "📊 Недостаточно данных для анализа. Добавь минимум 3 записи!\n"
                        "Нажми '➕ Записать день' чтобы начать.")
        return
    
    insights = analyzer.get_insights(entries)
    
    insights_text = "🔍 ТВОИ ПЕРСОНАЛЬНЫЕ ИНСАЙТЫ\n\n"
    for insight in insights:
        insights_text += f"• {insight}\n\n"
    
    bot.send_message(message.chat.id, insights_text, reply_markup=create_main_keyboard())

@bot.callback_query_handler(func=lambda call: True)
def handle_callback(call):
    user_id = call.from_user.id
    chat_id = call.message.chat.id
    
    if call.data.startswith("mood_"):
        mood = int(call.data.split("_")[1])
        
        if user_id not in user_sessions:
            user_sessions[user_id] = UserSession(user_id)
        
        session = user_sessions[user_id]
        session.mood = mood
        session.step = 1
        
        bot.edit_message_text("💼 Сколько часов ты потратил на полезную работу/учебу?",
                            chat_id, call.message.message_id,
                            reply_markup=create_hours_keyboard([0.5, 1, 2, 4], "work"))
    
    elif call.data.startswith("work_"):
        value = call.data.split("_")[1]
        
        if user_id in user_sessions:
            session = user_sessions[user_id]
            
            if value == "custom":
                bot.send_message(chat_id, "Введи количество часов работы/учебы (число):")
            else:
                session.work_hours = float(value)
                session.step = 2
                bot.edit_message_text("😴 Сколько часов ты спал?",
                                    chat_id, call.message.message_id,
                                    reply_markup=create_hours_keyboard([6, 7, 8, 9], "sleep"))
    
    elif call.data.startswith("sleep_"):
        value = call.data.split("_")[1]
        
        if user_id in user_sessions:
            session = user_sessions[user_id]
            
            if value == "custom":
                bot.send_message(chat_id, "Введи количество часов сна (число):")
            else:
                session.sleep_hours = float(value)
                session.step = 3
                
                keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
                keyboard.add(KeyboardButton("Пропустить"))
                
                bot.send_message(chat_id, "💭 Хочешь добавить комментарий? (Напиши текст или нажми 'Пропустить')",
                               reply_markup=keyboard)
    
    elif call.data.startswith("stats_"):
        period = call.data.split("_")[1]
        stats = db.get_statistics(user_id, period)
        
        if not stats:
            bot.send_message(chat_id, f"❌ Нет данных за {period}. Добавь записи!")
            return
        
        mood_avg = stats['avg_mood']
        mood_emoji = ["😞", "😐", "🙂", "😊", "🤩"][min(4, int(mood_avg)-1)] if mood_avg > 0 else "❓"
        
        stats_text = f"📊 СТАТИСТИКА ЗА {period.upper()}\n\n"
        stats_text += f"📅 Дней: {stats['days_count']}\n"
        stats_text += f"🎭 Среднее настроение: {mood_emoji} {mood_avg:.1f}/5\n"
        stats_text += f"📈 Максимум: {stats['max_mood']}/5 | Минимум: {stats['min_mood']}/5\n"
        stats_text += f"💼 Средняя работа: {stats['avg_work']:.1f} ч\n"
        stats_text += f"😴 Средний сон: {stats['avg_sleep']:.1f} ч\n"
        stats_text += f"📊 Всего работы: {stats['total_work']:.1f} ч\n"
        
        bot.send_message(chat_id, stats_text, reply_markup=create_main_keyboard())
    
    elif call.data == "insights":
        show_insights(call.message)
    
    elif call.data == "correlation":
        entries = db.get_entries(user_id, date.today() - timedelta(days=30), date.today())
        correlation_result = analyzer.get_correlation_analysis(entries)
        bot.send_message(chat_id, correlation_result, reply_markup=create_main_keyboard())
    
    elif call.data == "set_reminder":
        bot.send_message(chat_id, "Введи время напоминания в формате ЧЧ:ММ (например, 21:00):")
        bot.register_next_step_handler(call.message, set_reminder_time)
    
    elif call.data == "clear_confirm":
        if db.clear_user_data(user_id):
            bot.send_message(chat_id, "✅ Все твои данные успешно удалены! Начни с чистого листа.", 
                           reply_markup=create_main_keyboard())
        else:
            bot.send_message(chat_id, "❌ Ошибка при удалении данных.", reply_markup=create_main_keyboard())
    
    elif call.data == "clear_cancel":
        bot.send_message(chat_id, "✅ Операция отменена.", reply_markup=create_main_keyboard())
    
    elif call.data == "override_yes":
        if user_id in user_sessions:
            del user_sessions[user_id]
        start_entry(call.message)
    
    elif call.data == "override_no":
        bot.send_message(chat_id, "Операция отменена.", reply_markup=create_main_keyboard())
    
    bot.answer_callback_query(call.id)

def set_reminder_time(message):
    user_id = message.from_user.id
    time_str = message.text.strip()
    
    pattern = r'^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$'
    match = re.match(pattern, time_str)
    
    if match:
        hour = int(match.group(1))
        minute = int(match.group(2))
        
        if db.update_reminder_time(user_id, hour, minute):
            bot.send_message(message.chat.id, f"✅ Время напоминания установлено на {hour:02d}:{minute:02d}",
                           reply_markup=create_main_keyboard())
        else:
            bot.send_message(message.chat.id, "❌ Ошибка при сохранении времени", 
                           reply_markup=create_main_keyboard())
    else:
        bot.send_message(message.chat.id, "❌ Неверный формат! Используй ЧЧ:ММ (например, 21:00)",
                       reply_markup=create_main_keyboard())

def reminder_worker():
    """Фоновый поток для отправки напоминаний"""
    while True:
        now = datetime.now()
        current_time = now.strftime("%H:%M")
        
        # Здесь можно реализовать отправку напоминаний
        # Для упрощения пропускаем
        
        time.sleep(60)  # Проверяем каждую минуту

if __name__ == "__main__":
    logger.info("Бот запущен!")
    
    # Запускаем поток для напоминаний
    reminder_thread = threading.Thread(target=reminder_worker, daemon=True)
    reminder_thread.start()
    
    try:
        bot.infinity_polling()
    except KeyboardInterrupt:
        logger.info("Бот остановлен")